package com.devsu.hackerearth.backend.client.model.mapper;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

@Component
public class ClientMapper {

	public ClientDto toDto(Client client) {
		if (client == null) {
			return null;
		}

		ClientDto dto = new ClientDto();
		dto.setId(client.getId());
		dto.setPassword(client.getPassword());
		dto.setActive(client.isActive());
		dto.setName(client.getName());
		dto.setDni(client.getDni());
		dto.setGender(client.getGender());
		dto.setAge(client.getAge());
		dto.setAddress(client.getAddress());
		dto.setPhone(client.getPhone());
		return dto;
	}

	public Client toEntity(ClientDto dto) {
		if (dto == null) {
			return null;
		}
		Client client = new Client();
		client.setId(dto.getId());
		client.setPassword(dto.getPassword());
		client.setActive(dto.isActive());
		client.setName(dto.getName());
		client.setDni(dto.getDni());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		return client;
	}


}
