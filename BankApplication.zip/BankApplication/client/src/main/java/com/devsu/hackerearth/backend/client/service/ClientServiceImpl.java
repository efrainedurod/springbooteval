package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.model.mapper.ClientMapper;
 

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private final ClientMapper clientMapper;

	public ClientServiceImpl(ClientRepository clientRepository, ClientMapper clientMapper) {
		this.clientRepository = clientRepository;
		this.clientMapper = clientMapper;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll().stream()
					.map(clientMapper::toDto)
					.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		return clientRepository.findById(id)
					.map(clientMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Client not found"));
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client client = this.clientMapper.toEntity(clientDto);
		return clientMapper.toDto(clientRepository.save(client));
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Client client = this.clientMapper.toEntity (clientRepository
		  	        .findById(clientDto.getId())
					.map(clientMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Client not found")));

		client.setPassword(clientDto.getPassword());
		client.setActive(clientDto.isActive());
		client.setName(clientDto.getName());
		client.setDni(clientDto.getDni());
		client.setGender(clientDto.getGender());
		client.setAge(clientDto.getAge());
		client.setAddress(clientDto.getAddress());
		client.setPhone(clientDto.getPhone());

		return clientMapper.toDto(clientRepository.save(client));
	}

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        // Partial update account
		Client client = this.clientMapper.toEntity (clientRepository
		  	        .findById(id)
					.map(clientMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Client not found")));
		client.setActive(partialClientDto.isActive());
		return clientMapper.toDto(clientRepository.save(client));
    }

	@Override
	public void deleteById(Long id) {

		if (!clientRepository.existsById(id)){
			throw new EntityNotFoundException("Client not found");
		}

		clientRepository.deleteById(id);
	}
}
