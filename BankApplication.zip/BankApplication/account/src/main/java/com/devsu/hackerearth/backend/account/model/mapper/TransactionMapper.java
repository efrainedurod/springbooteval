package com.devsu.hackerearth.backend.account.model.mapper;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;


@Component
public class TransactionMapper {

	public  TransactionDto toDto(Transaction transaction) {
		if (transaction == null) {
			return null;
		}
		
		TransactionDto dto = new TransactionDto();
		dto.setId(transaction.getId());
		dto.setDate(transaction.getDate());
		dto.setType(transaction.getType());
		dto.setAmount(transaction.getAmount());
		dto.setBalance(transaction.getBalance());
		dto.setAccountId(transaction.getAccountId());

		return dto;
	}

	public Transaction toEntity(TransactionDto dto) {
		if (dto == null) {
			return null;
		}
		Transaction transaction = new Transaction();
		transaction.setId(dto.getId());
		transaction.setDate(dto.getDate());
		transaction.setType(dto.getType());
		transaction.setAmount(dto.getAmount());
		transaction.setBalance(dto.getBalance());
		transaction.setAccountId(dto.getAccountId());

		return transaction;
	}


}
