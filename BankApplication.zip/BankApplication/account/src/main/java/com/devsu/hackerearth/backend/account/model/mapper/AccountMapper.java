package com.devsu.hackerearth.backend.account.model.mapper;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;



@Component
public class AccountMapper {

	public AccountDto toDto(Account account) {
		if (account == null) {
			return null;
		}

		AccountDto dto = new AccountDto();
		dto.setId(account.getId());
		dto.setClientId(account.getClientId());
		dto.setNumber(account.getNumber());
		dto.setType(account.getType());
		dto.setInitialAmount(account.getInitialAmount());
		dto.setActive(account.isActive());

		return dto;
	}

 	public Account toEntity(AccountDto dto) {
		if (dto == null) {
			return null;
		}
		Account account = new Account();
		account.setId(dto.getId());
		account.setClientId(dto.getClientId());
		account.setNumber(dto.getNumber());
		account.setType(dto.getType());
		account.setInitialAmount(dto.getInitialAmount());
		account.setActive(dto.isActive());

		return account;
	}


}
