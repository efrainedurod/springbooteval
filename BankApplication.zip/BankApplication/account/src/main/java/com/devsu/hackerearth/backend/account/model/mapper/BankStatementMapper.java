package com.devsu.hackerearth.backend.account.model.mapper;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Component
public class BankStatementMapper {

	public  BankStatementDto toDto(Transaction transaction, Account account,String clientName) {

		if (transaction == null || account == null ) {
			return null;
		}
		BankStatementDto dto = new BankStatementDto();
		dto.setDate(transaction.getDate());
        dto.setClient(clientName);
        dto.setAccountNumber(account.getNumber());
        dto.setAccountType(account.getType());
        dto.setInitialAmount(account.getInitialAmount());
        dto.setActive(account.isActive());
        dto.setTransactionType(transaction.getType());
        dto.setAmount(transaction.getAmount());
        dto.setBalance(transaction.getBalance());

		return dto;
	}

}
