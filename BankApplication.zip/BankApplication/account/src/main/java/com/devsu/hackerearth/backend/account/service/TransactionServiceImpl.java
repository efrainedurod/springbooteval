package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.model.mapper.BankStatementMapper;
import com.devsu.hackerearth.backend.account.model.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

	private final TransactionRepository transactionRepository;
    private final TransactionMapper transactionMapper;
    private final AccountRepository accountRepository;
    private final BankStatementMapper bankStatementMapper;
    

	public TransactionServiceImpl(TransactionRepository transactionRepository, 
                                 TransactionMapper transactionMapper, AccountRepository accountRepository,
                                BankStatementMapper bankStatementMapper) {
		this.transactionRepository = transactionRepository;
        this.transactionMapper = transactionMapper;
        this.accountRepository = accountRepository;
        this.bankStatementMapper =  bankStatementMapper;
	}

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
		return transactionRepository.findAll().stream()
                    .map(transactionMapper::toDto)
                    .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
		return transactionRepository.findById(id)
					.map(transactionMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Transaction not found"));
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        Account account = accountRepository.findById(transactionDto.getAccountId())
                               .orElseThrow(()->new EntityNotFoundException("Account not found"));

        double newBalance = account.getInitialAmount() + transactionDto.getAmount();

        if (newBalance < 0){
            throw new IllegalStateException("Saldo no dispobible");
        }

        account.setInitialAmount(newBalance);
        Transaction transaction = transactionMapper.toEntity(transactionDto);
        transaction.setBalance(newBalance);

		return transactionMapper.toDto(transactionRepository.save(transaction));
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        List<Account> accounts = accountRepository.findByClientId(clientId);
        List<BankStatementDto> statements = new ArrayList<>();
      
        for (Account acc : accounts){
            List<Transaction> transactions = transactionRepository.findByAccountIdAndDateBetween(acc.getId(), dateTransactionStart, dateTransactionEnd);
            for (Transaction tx : transactions ){
                statements.add(bankStatementMapper.toDto(tx,acc,"Cliente "+ clientId));
            }
        }
		return statements;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
		return null;
    }
    
}
