package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.model.mapper.AccountMapper;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;
    private final AccountMapper accountMapper;

	public AccountServiceImpl(AccountRepository accountRepository,AccountMapper accountMapper) {
		this.accountRepository = accountRepository;
        this.accountMapper = accountMapper;
	}

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
		return  accountRepository.findAll().stream()
                    .map(accountMapper::toDto)
                    .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
		return accountRepository.findById(id)
                    .map(accountMapper::toDto)
                    .orElseThrow(()->new EntityNotFoundException("Account not found"));
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
		Account account = this.accountMapper.toEntity(accountDto);
		return accountMapper.toDto(accountRepository.save(account));
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
		Account account = this.accountMapper.toEntity (accountRepository
		  	        .findById(accountDto.getId())
					.map(accountMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Account not found")));
		account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setActive(accountDto.isActive());

		return accountMapper.toDto(accountRepository.save(account));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account  account = accountRepository.findById(id)
                    .orElseThrow(()->new EntityNotFoundException("Account not found"));
		account.setActive(partialAccountDto.isActive());
		return accountMapper.toDto(accountRepository.save(account));
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        this.accountMapper.toEntity (accountRepository
		  	        .findById(id)
					.map(accountMapper::toDto)
					.orElseThrow(()->new EntityNotFoundException("Account not found")));
		accountRepository.deleteById(id);
    }
    
}
